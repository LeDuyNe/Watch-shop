function checkInputChange(inp) {
    if (inp.value != '') inp.classList.add('has-content');
    else inp.classList.remove('has-content');
}